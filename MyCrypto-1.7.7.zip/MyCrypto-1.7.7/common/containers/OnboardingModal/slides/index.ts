export { default as FirstSlide } from './FirstSlide';
export { default as SecondSlide } from './SecondSlide';
export { default as ThirdSlide } from './ThirdSlide';
export { default as FourthSlide } from './FourthSlide';
