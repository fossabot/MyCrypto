export { default } from './Mnemonic';
