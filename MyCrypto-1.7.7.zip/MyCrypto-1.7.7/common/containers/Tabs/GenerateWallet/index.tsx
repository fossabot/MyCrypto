export { default } from './GenerateWallet';
