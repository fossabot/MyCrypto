export { default } from './NewHeader';
